<?php

namespace Database\Seeders;

use App\Models\City;
use App\Models\User;
use Faker\Provider\kk_KZ\Address;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        for ($i=1;$i<15;$i++){
        	$city = [
        		'name'=>Address::region(),
			];
        	City::query()->create($city);
		}
    }
}
