<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DowntimeController extends Controller
{
    //
}
