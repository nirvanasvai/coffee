<?php if($item->status==1): ?>
    bg-success
<?php elseif($item->status ==2): ?>
    bg-warning
<?php else: ?>
    bg-danger
<?php endif; ?>
<?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/components/status.blade.php ENDPATH**/ ?>