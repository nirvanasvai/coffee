<?php if(auth()->check()): ?>
    <div id="mySidenav" class="sidenav">
        <span class="closebtn" onclick="closeNav()">&#9776;</span>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-link">
                <a style="font-size: 15px" href="<?php echo e(route($item['route'])); ?>" class="page-link alert-link <?php if($item['active']): ?>
                        text-info
<?php endif; ?>"><?php echo e($item['title']); ?></a>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div id="main">
        <div class="toggle">
            <div class="group-buttons"></div>
            <span class="toggle-button" onclick="openNav()">&#9776;</span>
        </div>
    </div>

<?php endif; ?>
<?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/components/menu.blade.php ENDPATH**/ ?>