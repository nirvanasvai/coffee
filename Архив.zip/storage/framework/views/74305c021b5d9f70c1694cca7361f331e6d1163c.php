<?php $__env->startSection('title',$device->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-title text-center">
                <h3><?php echo e($device->cityRelationship->name); ?> - <?php echo e($device->companyRelationship->name); ?> - <?php echo e($device->name); ?></h3>
            </div>
        </div>
       <div class="row">
           <div class="col-sm-4">
               <ul class="list-group">
                   <li class="list-group-item <?php if($device->cocoa == 0): ?>
                       bg-danger
                       <?php elseif($device->cocoa <=30): ?>
                           bg-warning
                           <?php else: ?>
                           bg-success
                   <?php endif; ?>">Cocoa <?php echo e($device->cocoa); ?>%</li>
                   <li class="list-group-item <?php if($device->coffee == 0): ?>
                           bg-danger
<?php elseif($device->coffee <=30): ?>
                           bg-warning
                           <?php else: ?>
                           bg-success
                   <?php endif; ?>">Coffee <?php echo e($device->coffee); ?>%</li>
                   <li class="list-group-item <?php if($device->water == 0): ?>
                           bg-danger
<?php elseif($device->water <=30): ?>
                           bg-warning
                           <?php else: ?>
                           bg-success
                   <?php endif; ?>">Water <?php echo e($device->water); ?>%</li>
                   <li class="list-group-item <?php if($device->milk == 0): ?>
                           bg-danger
<?php elseif($device->milk <=30): ?>
                           bg-warning
                           <?php else: ?>
                           bg-success
                   <?php endif; ?>">Milk <?php echo e($device->milk); ?>%</li>
                   <?php if(isset($device->errorRelationship->code)): ?>
                       <li class="list-group-item pt-4"><?php echo e($device->errorRelationship->code); ?></li>
                   <?php else: ?>
                       <li class="list-group-item pt-4">Нет</li>
                   <?php endif; ?>
               </ul>
               <a href="<?php echo e(route('device.edit',$device)); ?>"> <button class="btn btn-primary">Изменить</button></a>
           </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/device/inner_device.blade.php ENDPATH**/ ?>