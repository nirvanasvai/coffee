<?php $__env->startSection('content'); ?>

    <div class="container">
        <br>
        <h2>Пользователи</h2>
        <br>
        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>
        <table class="table table-striped table-borderless">
            <thead class="thead-dark">
            <th>Имя</th>
            <th>Email</th>
            <th>Роль</th>
            <th class="text-right">Действие</th>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                   <?php if($user->role ==1): ?>
                        <td>Администратор</td>
                    <?php else: ?>
                       <td>Пользователь</td>
                   <?php endif; ?>
                    <td class="text-right">
                        <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="<?php echo e(route('user.destroy', $user)); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>

                            <a class="btn btn-primary" href="<?php echo e(route('user.edit', $user)); ?>"><i class="fa fa-edit"></i></a>

                            <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/user/index.blade.php ENDPATH**/ ?>