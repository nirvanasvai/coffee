<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(auth()->user()->role ==1): ?>
            <a href="<?php echo e(route('device.create')); ?>" class="btn btn-primary mt-4"><i class="far fa-plus-square"></i> Создать</a>

        <?php endif; ?>
        <div class="row">
           <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 pt-2">
                    <div class="card <?php echo $__env->make('components.status',['item'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>">
                        <div class="card-body">
                            <a class="nav-link text-dark" href="<?php echo e(route('device.inner',$item->id)); ?>">
                                <p class="card-title"><?php echo e($item->name); ?></p>
                            </a>
                        </div>
                    </div>
                </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/device/index.blade.php ENDPATH**/ ?>