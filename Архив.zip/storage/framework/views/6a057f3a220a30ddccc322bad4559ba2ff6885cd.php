<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="form-authorization__error error-authorization">
        <div class="error-authorization__row">
            <div class="error-authorization__col">
                <div class="error-authorization__alert">
                    <img src="/public/img/authorization/report.svg" alt="" />
                </div>
            </div>
            <div class="error-authorization__col">
                <div class="error-authorization__text" id="dump">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <a href="" class="error-authorization__close"></a>
    </div>
<?php endif; ?>
<?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/components/message.blade.php ENDPATH**/ ?>