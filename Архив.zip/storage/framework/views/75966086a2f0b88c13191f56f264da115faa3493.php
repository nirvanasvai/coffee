<?php $__env->startSection('title',$city->name); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card">
            <h4 class="card-header text-center"><?php echo e($city->name); ?></h4>
            <div class="row pt-2 mb-2 ml-1 mr-1">
            <?php $__currentLoopData = $city->device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6">
                        <div class="card <?php if($item->status == 1): ?>
                            bg-success
                            <?php elseif($item->status == 2): ?>
                                bg-warning
                                <?php else: ?>
                                bg-danger
                        <?php endif; ?>">
                            <div class="card-body">
                                <a href="<?php echo e(route('device.inner',$item->id)); ?>" class="nav-link text-dark">
                                    <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                </a>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/device/inner.blade.php ENDPATH**/ ?>