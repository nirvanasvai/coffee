<?php $__env->startSection('content'); ?>

    <div class="container">
        <br>
        <h2>Компании</h2>
        <br>
        <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>
        <table class="table table-striped table-borderless">
            <thead class="thead-dark">
            <th>Название</th>
            <th class="text-right">Действие</th>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($company->name); ?></td>
                    <td class="text-right">
                        <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="<?php echo e(route('company.destroy', $company)); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>

                            <a class="btn btn-primary" href="<?php echo e(route('company.edit', $company)); ?>"><i class="fa fa-edit"></i></a>

                            <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/company/index.blade.php ENDPATH**/ ?>