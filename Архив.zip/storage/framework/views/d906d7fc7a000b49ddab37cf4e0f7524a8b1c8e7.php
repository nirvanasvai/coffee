<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <form action="<?php echo e(route('device.store')); ?>" method="post" class="list-group-horizontal">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <select class="custom-select" name="city_id" required>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                       <select name="name" class="custom-select form-control" required>
                           <option value="WMF 1500S">WMF 1500S</option>
                           <option value="WMF 1500S+">WMF 1500S+</option>
                           <option value="WMF 5000S">WMF 5000S</option>
                           <option value="WMF 5000S+">WMF 5000S+</option>
                           <option value="WMF 1100S">WMF 1100S</option>
                           <option value="WMF 1200S">WMF 1200S </option>
                           <option value="WMF 1800S">WMF 1800S</option>
                       </select>
                    </div>
                    <div class="form-group">
                        <select name="error_id" class="custom-select form-control" required>
                            <?php $__currentLoopData = $errorLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->code); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="company_id" class="custom-select form-control" required>
                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Код</label>
                        <input type="text" class="form-control" name="code" required>
                    </div>
                </div>

                <div class="form-group text-center">
                    <button class="btn btn-primary" type="submit">Сохранить</button>
                </div>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/device/create.blade.php ENDPATH**/ ?>