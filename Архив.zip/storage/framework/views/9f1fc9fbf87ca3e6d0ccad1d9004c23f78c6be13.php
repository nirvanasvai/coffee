<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>

    <div class="row">
        <div class="col-sm-3 pt-2">
            <div class="card bg-success">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-success">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-danger">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-warning">
                <div class="card-body">
                    <p class="card-title">Алматы</p>
                    <p class="card-text">АСЗ Луганского 1</p>
                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-success">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-success">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-danger">
                <div class="card-body">
                    <p class="card-title">Нур-Султан</p>
                    <p class="card-text">АСЗ Луганского 1</p>

                </div>
            </div>
        </div>
        <div class="col-sm-3 pt-2">
            <div class="card bg-warning">
                <div class="card-body">
                    <p class="card-title">Алматы</p>
                    <p class="card-text">АСЗ Луганского 1</p>
                </div>
            </div>
        </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/home.blade.php ENDPATH**/ ?>