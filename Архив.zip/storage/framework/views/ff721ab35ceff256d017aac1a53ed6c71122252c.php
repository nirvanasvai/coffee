<?php $__env->startSection('content'); ?>

    <div class="container">

        <br>
        <h2>Редактирование Компании</h2>
        <hr />

        <form class="form-horizontal" action="<?php echo e(route('company.update', $company)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>


            
            <?php echo $__env->make('company.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/company/edit.blade.php ENDPATH**/ ?>