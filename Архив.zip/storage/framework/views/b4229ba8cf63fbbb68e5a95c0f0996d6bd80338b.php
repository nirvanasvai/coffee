<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($item->name); ?></h3>

        <p class="<?php if($item->coca): ?>

        <?php endif; ?>"> Cocoa <?php echo e($item->cocoa); ?>%</p>
        <p>Coffee <?php echo e($item->coffee); ?>%</p>
        <p>Water <?php echo e($item->water); ?>%</p>
        <p>Milk <?php echo e($item->milk); ?>%</p>
        <p>Error <?php echo e($item->error_id); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Stam/Desktop/Project/coffee/resources/views/test.blade.php ENDPATH**/ ?>